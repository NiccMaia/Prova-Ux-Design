import { DarkMode } from './darkMode.js';
import { TaskArea } from './addTask.js';
import { currentDay } from './currentDay.js';

DarkMode();
currentDay();
TaskArea();